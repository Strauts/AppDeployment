<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb_NO">
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="logindialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="57"/>
        <source>Brukernavn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="81"/>
        <source>Passord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="154"/>
        <source>Lag konto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="178"/>
        <source>Har du ikke konto?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="202"/>
        <source>Registrer deg nedenfor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="218"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="242"/>
        <source>Glemt passord?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="262"/>
        <source>Endre passord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="282"/>
        <source>Bruker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logindialog.ui" line="302"/>
        <source>Ansatt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="45"/>
        <source>Ukes Kalender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="56"/>
        <source>Tor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="68"/>
        <source> Tir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="80"/>
        <source>Lør</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>Ons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="104"/>
        <source>  8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="116"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="128"/>
        <source> Man</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="140"/>
        <source>  7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="152"/>
        <source>Fre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="164"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="176"/>
        <source>  9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="188"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="200"/>
        <source>Søn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="298"/>
        <source>Gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="315"/>
        <source>Bytt til Arbeider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="329"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="350"/>
        <source>God Morgen, Ola!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="371"/>
        <source>  Februar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="387"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="396"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="73"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProfileDialog</name>
    <message>
        <location filename="profiledialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="62"/>
        <source>Gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="96"/>
        <source>Belønninger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="113"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="130"/>
        <source>Innstillinger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="152"/>
        <source>Ola Berg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profiledialog.ui" line="165"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuestionDialog</name>
    <message>
        <location filename="questiondialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="questiondialog.ui" line="29"/>
        <location filename="questiondialog.ui" line="42"/>
        <location filename="questiondialog.ui" line="106"/>
        <location filename="questiondialog.ui" line="119"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="questiondialog.ui" line="59"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="questiondialog.ui" line="76"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="questiondialog.ui" line="93"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="questiondialog.ui" line="136"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecondWindowDialog</name>
    <message>
        <location filename="secondwindowdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="secondwindowdialog.ui" line="29"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="secondwindowdialog.ui" line="84"/>
        <source>Tror du dette er riktig svar? </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>avatarDialog</name>
    <message>
        <location filename="avatardialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="avatardialog.ui" line="43"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="avatardialog.ui" line="64"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>calenderDialog</name>
    <message>
        <location filename="calenderdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="calenderdialog.ui" line="44"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changePWDialog</name>
    <message>
        <location filename="changepwdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>commentDialog</name>
    <message>
        <location filename="commentdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="commentdialog.ui" line="44"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Kommenter - kommentar vil bli koblet til brukerID&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="commentdialog.ui" line="70"/>
        <source>Kommentar Oppgave &quot;x&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>homepageDialog</name>
    <message>
        <location filename="homepagedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="44"/>
        <source>Ukes Kalender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="55"/>
        <source>Tor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="67"/>
        <source> Tir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="79"/>
        <source>Lør</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="91"/>
        <source>Ons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="103"/>
        <source>  8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="115"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="127"/>
        <source> Man</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="139"/>
        <source>  7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="151"/>
        <source>Fre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="163"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="175"/>
        <source>  9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="187"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="199"/>
        <source>Søn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="211"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="265"/>
        <source>Brukerliste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="298"/>
        <source>Gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="315"/>
        <source>Database Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="329"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="350"/>
        <source>God Morgen, Ola!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="homepagedialog.ui" line="371"/>
        <source>  Februar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>patientDialog</name>
    <message>
        <location filename="patientdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientdialog.ui" line="71"/>
        <source>What information about the usert is wanted in this page?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientdialog.ui" line="102"/>
        <source>Bruker Liste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>patientInformationDialog</name>
    <message>
        <location filename="patientinformationdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientinformationdialog.ui" line="29"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientinformationdialog.ui" line="50"/>
        <source>Ola Berg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientinformationdialog.ui" line="71"/>
        <source>22. Oslo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="patientinformationdialog.ui" line="120"/>
        <source>Bruker Informasjon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt5DatabaseDialog</name>
    <message>
        <location filename="qt5databasedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qt5databasedialog.ui" line="33"/>
        <source>Database Connection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>registerDialog</name>
    <message>
        <location filename="registerdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="44"/>
        <source>Fornavn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="60"/>
        <source>Mellomnavn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="76"/>
        <source>Etternavn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="92"/>
        <source>Telefon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="108"/>
        <source>E-Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="124"/>
        <source>Passord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="140"/>
        <source>Gjenta Passord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="226"/>
        <source>Bruker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="242"/>
        <source>Ansatt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="259"/>
        <source>Registrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="275"/>
        <source>Brukernavn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="registerdialog.ui" line="307"/>
        <source>Registrer Konto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>resourceHandlerDialog</name>
    <message>
        <location filename="resourcehandlerdialog.ui" line="13"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>resultsDialog</name>
    <message>
        <location filename="resultsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="64"/>
        <source>   Spørsmål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="79"/>
        <source>       Svar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="94"/>
        <source>       Fasit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="109"/>
        <source>Kommentar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="137"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     3&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="151"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="177"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     2&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="191"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     9&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="211"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     6&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="228"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     7&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="251"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="268"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     4&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="282"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     8&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="311"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;    10&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resultsdialog.ui" line="360"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rewardDialog</name>
    <message>
        <location filename="rewarddialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>settingsDialog</name>
    <message>
        <location filename="settingsdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.ui" line="51"/>
        <location filename="settingsdialog.ui" line="68"/>
        <location filename="settingsdialog.ui" line="85"/>
        <location filename="settingsdialog.ui" line="102"/>
        <location filename="settingsdialog.ui" line="119"/>
        <location filename="settingsdialog.ui" line="136"/>
        <source>Placeholder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingsdialog.ui" line="158"/>
        <source>Innstillinger</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tasksDialog</name>
    <message>
        <location filename="tasksdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="37"/>
        <source>I dag </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="43"/>
        <source>Ta SexKunn testen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="50"/>
        <source>Møte Ingunn kl. 13.00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="81"/>
        <source>I morgen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="87"/>
        <source>Gå tur med Geir kl. 10.00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="125"/>
        <source>Senere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="131"/>
        <source>Repeter SexKunn testen innen Fredag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="169"/>
        <source>Gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="198"/>
        <location filename="tasksdialog.ui" line="211"/>
        <location filename="tasksdialog.ui" line="224"/>
        <location filename="tasksdialog.ui" line="237"/>
        <location filename="tasksdialog.ui" line="250"/>
        <location filename="tasksdialog.ui" line="263"/>
        <location filename="tasksdialog.ui" line="276"/>
        <location filename="tasksdialog.ui" line="289"/>
        <location filename="tasksdialog.ui" line="302"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="tasksdialog.ui" line="319"/>
        <source>Legg til gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>workerProfileDialog</name>
    <message>
        <location filename="workerprofiledialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="37"/>
        <source>Ola Berg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="82"/>
        <source>Gjøremål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="115"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="132"/>
        <source>Innstillinger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="149"/>
        <source>Brukerliste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerprofiledialog.ui" line="163"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>workerResultDialog</name>
    <message>
        <location filename="workerresultdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="43"/>
        <source>   Spørsmål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="58"/>
        <source>       Svar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="73"/>
        <source>       Fasit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="88"/>
        <source>Kommentar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="132"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     5&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="155"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     1&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="178"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     9&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="192"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     2&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="206"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;    10&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="226"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     7&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="240"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     6&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="254"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     3&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="271"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     8&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="300"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;     4&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="workerresultdialog.ui" line="330"/>
        <location filename="workerresultdialog.ui" line="341"/>
        <location filename="workerresultdialog.ui" line="352"/>
        <location filename="workerresultdialog.ui" line="363"/>
        <location filename="workerresultdialog.ui" line="374"/>
        <location filename="workerresultdialog.ui" line="385"/>
        <location filename="workerresultdialog.ui" line="396"/>
        <location filename="workerresultdialog.ui" line="407"/>
        <location filename="workerresultdialog.ui" line="418"/>
        <location filename="workerresultdialog.ui" line="429"/>
        <source>Legg til</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
